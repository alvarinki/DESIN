var nombre = "guille", apellido = "balsera", edadInicio = 24, nCursos = 2;

console.log(typeof nombre + " " + typeof apellido + " " + typeof edadInicio + " " + typeof nCursos);
console.log(nombre + "\n" + apellido + "\n" + (edadInicio + nCursos));

