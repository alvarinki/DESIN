var nombre="Álvaro"
var apellidos="Candanedo"
var edad=20
var aniosRestantes=2

console.log(typeof nombre + " " + typeof apellidos + " "+ typeof edad +" "+ typeof aniosRestantes)
console.log(nombre +"\n"+ apellidos + "\n"+ "Me graduaré con "+(edad+aniosRestantes) )